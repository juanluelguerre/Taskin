﻿// ---------------------------------------------------------------------------------
// <copyright file="IProjectRepository.cs" Author="Juan Luis Guerrero Minero" www="elGuerre.com">
//     Copyright (c) elGuerre.com. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------------
using ElGuerre.OneRest.$safeprojectname$.Data.Entity;

namespace ElGuerre.OneRest.$safeprojectname$.Data.Repository
{
    public interface IProjectRepository : IEntityRepository<ProjectEntity, int>
    {
    }
}
