﻿// ---------------------------------------------------------------------------------
// <copyright file="MappingConfig.cs" Author="Juan Luis Guerrero Minero" www="elGuerre.com">
//     Copyright (c) elGuerre.com. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------------
using ElGuerre.OneRest.$safeprojectname$.Data.Entity;

namespace ElGuerre.OneRest.$safeprojectname$.Models
{
    public static class MappingConfig
    {
        public static void RegisterMaps()
        {
            AutoMapper.Mapper.Initialize(config =>
            {
                //config.AddProfile<MapProfile>();
                config.CreateMap<ProjectModel, ProjectEntity>();
                config.CreateMap<ProjectEntity, ProjectModel>();
            });
        }
    }
}
