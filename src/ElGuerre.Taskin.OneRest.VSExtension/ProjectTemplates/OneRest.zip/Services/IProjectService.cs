﻿using ElGuerre.OneRest.$safeprojectname$.Models;

namespace ElGuerre.OneRest.$safeprojectname$.Services
{
    public interface IProjectService : IBaseService<ProjectModel, int>
    {
    }
}
