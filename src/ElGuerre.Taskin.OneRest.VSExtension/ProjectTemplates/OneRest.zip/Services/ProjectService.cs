﻿// ---------------------------------------------------------------------------------
// <copyright file="ProjectService.cs" Author="Juan Luis Guerrero Minero" www="elGuerre.com">
//     Copyright (c) elGuerre.com. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------------------
using ElGuerre.OneRest.$safeprojectname$.Data;
using ElGuerre.OneRest.$safeprojectname$.Data.Entity;
using ElGuerre.OneRest.$safeprojectname$.Data.Repository;
using ElGuerre.OneRest.$safeprojectname$.Models;

namespace ElGuerre.OneRest.$safeprojectname$.Services
{
    public class ProjectService : BaseService<ProjectModel, ProjectEntity, int>, IProjectService
    {
        public ProjectService(IProjectRepository repository, IUnitOfWork unitOfWork) 
            : base(repository, unitOfWork)
        {
        }
    }
}
